import datetime

print("microseconds......:{}".format(datetime.timedelta(microseconds=1)))
print("milliseconds......:{}".format(datetime.timedelta(milliseconds=1)))
print("seconds...........:{}".format(datetime.timedelta(seconds=1)))
print("minutes...........:{}".format(datetime.timedelta(minutes=1)))
print("hours.............:{}".format(datetime.timedelta(hours=1)))
print("days..............:{}".format(datetime.timedelta(days=1)))
print("weeks.............:{}".format(datetime.timedelta(weeks=1)))