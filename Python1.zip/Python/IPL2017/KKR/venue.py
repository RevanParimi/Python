def printVenue():
	print("Kolkotta")
def printStadium():
	print("Eden Garden")