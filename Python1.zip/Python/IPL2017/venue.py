def printVenue():
	print("Mumbai")
def printStadium():
	print("Wankande Stadium")