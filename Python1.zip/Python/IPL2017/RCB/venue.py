def printVenue():
	print("Bangalore")
def printStadium():
	print("Chinnaswamy Stadium")