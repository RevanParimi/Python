import os
os.mkdir("test")