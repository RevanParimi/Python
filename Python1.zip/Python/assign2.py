alp=input("Enter the string  ")
if alp in ["Yes","YES","yes"]:
	print "Yes"
else:
	print "No"
