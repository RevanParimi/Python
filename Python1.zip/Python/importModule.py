#Approach
from IPL2017 import venue
venue.printVenue()
venue.printStadium()
print("--------------------------")
#Approach2
from IPL2017.venue import printVenue
printVenue()