#Approach 1
from IPL2017.KKR import venue

venue.printVenue()
venue.printStadium()
print("---------------------------")
#Approach 2
from IPL2017.KKR.venue import printStadium
from IPL2017.KKR.venue import printVenue

printVenue()
printStadium()