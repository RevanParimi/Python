import sys
for index, item in enumerate(sys.path):
	print(index, item)