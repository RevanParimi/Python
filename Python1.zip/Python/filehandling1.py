
with open("ExceptionHandling.txt") as fp:
	for line in fp:

		print (line)



fp.close()
# for line in "Demo.txt":
# 	print(line)