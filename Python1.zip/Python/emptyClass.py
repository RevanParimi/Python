class Employee:
	pass
e1=Employee()
e2=Employee()

print(e1)
print(e2)