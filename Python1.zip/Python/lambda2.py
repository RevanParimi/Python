f= lambda num:num*num
print(f(10))
addNos = lambda x, y: x+y
print(addNos(3,5))

max=lambda x,y :x if x > y else y
print(max(7,10))