#Dictionaries
#Collecion of Key-Value pairs
#Syntax to create dictionary is : {}
fruits={"a":"apple","b":"Banana","c":"cherry"}
print(fruits)
print(type(fruits))