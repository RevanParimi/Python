import random

mylist = ["India",True,1000,"Rain","Bangalore",False,3.5]

print(random.choice(mylist))