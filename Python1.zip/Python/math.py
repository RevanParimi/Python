#import math  #with prefix
from math import factorial##no need prefix
from math import pi

print(factorial(10))
print(pi)