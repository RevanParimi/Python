class Employee:
	'''
	Help: An Employee Class Details
	This calss is demonstrate __doc__property
	'''
e1=Employee()

print("Employee e1.....:{0}".format(e1))
print("--------------------------------------------")
print("Employee e1.....:{0}".format(Employee.__doc__))
print("--------------------------------------------")
print("Employee e1.....:{0}".format(e1.__doc__))
