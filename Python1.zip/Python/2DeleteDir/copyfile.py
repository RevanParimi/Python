from shutil import copy
from shutil import copyfile

copyfile("copyFile.py","copyFile2.py")
copy("copyfile.py","2DeleteDir")